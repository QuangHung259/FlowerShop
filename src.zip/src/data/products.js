export const products = [
    { id: 1, name: "Hoa Hồng Đỏ", price: 100000, image: "/images/rose.jpg" },
    { id: 2, name: "Hoa Ly", price: 150000, image: "/images/ly.jpg" },
    { id: 3, name: "Hoa cẩm tú cầu", price: 80000, image: "/images/camtucau.jpg" },
    { id: 4, name: "Hoa cẩm tú cầu", price: 80000, image: "/images/camtucau.jpg" },
    { id: 5, name: "Hoa cẩm tú cầu", price: 80000, image: "/images/camtucau.jpg" },
    { id: 6, name: "Hoa cẩm tú cầu", price: 80000, image: "/images/camtucau.jpg" },
    { id: 7, name: "Hoa cẩm tú cầu", price: 80000, image: "/images/camtucau.jpg" },
    { id: 8, name: "Hoa cẩm tú cầu", price: 80000, image: "/images/camtucau.jpg" },
    { id: 9, name: "Hoa cẩm tú cầu", price: 80000, image: "/images/camtucau.jpg" },
    { id: 10, name: "Hoa cẩm tú cầu", price: 80000, image: "/images/camtucau.jpg" },
    { id: 11, name: "Hoa cẩm tú cầu", price: 80000, image: "/images/camtucau.jpg" },
    { id: 12, name: "Hoa cẩm tú cầu", price: 80000, image: "/images/camtucau.jpg" },
    { id: 13, name: "Hoa cẩm tú cầu", price: 80000, image: "/images/camtucau.jpg" },
    { id: 14, name: "Hoa cẩm tú cầu", price: 80000, image: "/images/camtucau.jpg" },
    { id: 15, name: "Hoa cẩm tú cầu", price: 80000, image: "/images/camtucau.jpg" },
    { id: 16, name: "Hoa cẩm tú cầu", price: 80000, image: "/images/camtucau.jpg" },

  ];
  