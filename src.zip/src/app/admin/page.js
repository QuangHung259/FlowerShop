export default function AdminPage() {
    return (
      <div>
        <h1>Trang Quản Lý</h1>
        <p>Chức năng quản lý sẽ được cập nhật.</p>
      </div>
    );
  }
  